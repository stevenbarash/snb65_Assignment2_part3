import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AlbumUtils {
	public Album createAlbum(String title, String releaseDate, String coverImagePath, String recordingCompanyName,
			String numberOfTracks, String pmrcRating, double length) {

		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = new Album();
		a.setAlbumID(UUID.randomUUID().toString());
		a.setTitle(title);
		a.setLength(length);
		a.setReleaseDate(releaseDate);
		a.setNumberOfTracks(numberOfTracks);
		a.setCoverImagePath(coverImagePath);
		a.setRecordingCompanyName(recordingCompanyName);
		a.setPmrcRating(pmrcRating);

		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album findExistingAlbum(String albumID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		return a;

	}
	/*
	 * Must reset the variable to the Album returned by this class
	 */

	public Album updateTitle(String albumID, String title) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setTitle(title);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album updateLength(String albumID, double length) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setLength(length);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album updateReleaseDate(String albumID, String releaseDate) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setReleaseDate(releaseDate);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album updateCoverImagePath(String albumID, String coverImagePath) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setCoverImagePath(coverImagePath);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album updateRecordingCompanyName(String albumID, String recordingCompanyName) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setRecordingCompanyName(recordingCompanyName);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Album updatePmrcRating(String albumID, String pmrcRating) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		a.setPmrcRating(pmrcRating);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public void DeleteAlbum(String albumID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album s = emanager.find(Album.class, albumID);
		emanager.remove(s);

		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

	}

	public Album addSong(String albumID, String songID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Album a = emanager.find(Album.class, albumID);
		Song s = emanager.find(Song.class, songID);

		a.setAlbumSongs(s);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

}
