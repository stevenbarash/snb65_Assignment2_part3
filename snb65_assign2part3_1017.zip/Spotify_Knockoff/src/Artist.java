import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The type Artist.
 */
@Entity
@Table(name = "artist")
public class Artist {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	@Column(name = "artist_id")
	private String artistID;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "band_name")
	private String bandName;

	@Column(name = "bio")
	private String bio;

	/**
	 * Constructor for new Artist. JPA takes care of things from here
	 */
	public Artist() {
		super();
	}

	public String getArtistID() {
		return artistID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBandName() {
		return bandName;
	}

	public void setBandName(String bandName) {
		this.bandName = bandName;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public void setArtistID(String artistID) {
		this.artistID = artistID;
	}

	// public Artist(String firstName, String lastName, String bandName, String bio)
	// {
	// this.firstName = firstName;
	// this.lastName = lastName;
	// this.bandName = bandName;
	// this.bio = bio;
	// this.artistID = UUID.randomUUID().toString();
	//
	// String sql = "INSERT INTO artist
	// (artist_id,first_name,last_name,band_name,bio) ";
	// sql += "VALUES (?, ?, ?, ?, ?);";
	// System.out.println(sql);
	//
	// try {
	// DbUtilities db = new DbUtilities();
	// Connection conn = db.getConn();
	// PreparedStatement ps = conn.prepareStatement(sql);
	// ps.setString(1, this.artistID);
	// ps.setString(2, this.firstName);
	// ps.setString(3, this.lastName);
	// ps.setString(4, this.bandName);
	// ps.setString(5, this.bio);
	// ps.executeUpdate();
	// db.closeDbConnection();
	// db = null;
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// }
	//
	// /**
	// * Constructor for existing Artist. Sets local variables to those of an artist
	// * in the DB
	// *
	// * @param artistID
	// * input for selecting which artist to query
	// * @throws SQLException
	// */
	//
	// public Artist(String artistID) {
	// String sql = "SELECT * FROM artist WHERE artist_id = '" + artistID + "';";
	// DbUtilities db = new DbUtilities();
	// try {
	// ResultSet rs = db.getResultSet(sql);
	// while (rs.next()) {
	// this.artistID = rs.getString("artist_id");
	// this.firstName = rs.getString("first_name");
	// this.lastName = rs.getString("last_name");
	// this.bandName = rs.getString("band_name");
	// this.bio = rs.getString("bio");
	// }
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// }
	//
	// /**
	// * Getter for this object's artistID
	// *
	// * @return String artistID
	// */
	//
	// public String getArtistID() {
	// return artistID;
	// }
	//
	// /**
	// * Deletes an artist based on inputted artistID from the Database. MUST DELETE
	// * THE OBJECT AFTER RUNNING THIS.
	// *
	// * @param artistID
	// * the ID of the artist you wish to delete.
	// */
	// public void deleteArtist(String artistID) {
	// String sql = "DELETE FROM song_artist WHERE fk_artist_id = '" + artistID +
	// "';";
	// System.out.println(sql);
	//
	// DbUtilities db = new DbUtilities();
	// db.executeQuery(sql);
	// sql = "DELETE FROM artist WHERE artist_id = '" + artistID + "';";
	// System.out.println(sql);
	// db.executeQuery(sql);
	// db.closeDbConnection();
	// db = null;
	// }
}
