import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ArtistUtils {
	public Artist createArtist(String firstName, String lastName, String bio) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = new Artist();
		a.setArtistID(UUID.randomUUID().toString());
		a.setFirstName(firstName);
		a.setLastName(lastName);
		a.setBio(bio);

		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;
	}

	public Artist createBand(String bandName, String bio) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = new Artist();
		a.setArtistID(UUID.randomUUID().toString());
		a.setBandName(bandName);
		a.setBio(bio);

		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;
	}

	public Artist findExistingArtist(String artistID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		return a;

	}
	/*
	 * Must reset the variable to the Artist returned by each update method
	 */

	public Artist updateFirstName(String artistID, String firstName) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		a.setFirstName(firstName);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Artist updateLastName(String artistID, String lastName) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		a.setLastName(lastName);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Artist updateBandName(String artistID, String bandName) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		a.setBandName(bandName);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public Artist updateBio(String artistID, String bio) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		a.setBio(bio);
		emanager.persist(a);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return a;

	}

	public void DeleteArtist(String artistID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);
		emanager.remove(a);

		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

	}

}
