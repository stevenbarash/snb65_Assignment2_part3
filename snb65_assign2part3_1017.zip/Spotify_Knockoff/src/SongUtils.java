import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SongUtils {
	public void DeleteSong(String songID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		emanager.remove(s);

		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

	}

	public Song createSong(String title, double length, String releaseDate, String recordDate) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = new Song();
		s.setSongID(UUID.randomUUID().toString());
		s.setTitle(title);
		s.setLength(length);
		s.setReleaseDate(releaseDate);
		s.setRecordDate(recordDate);
		s.setFilePath("");

		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;
	}

	public Song findExistingSong(String songID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		return s;

	}

	public Song updateTitle(String songID, String title) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		s.setTitle(title);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

	public Song updateLength(String songID, double length) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		s.setLength(length);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

	public Song updateReleaseDate(String songID, String releaseDate) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		s.setReleaseDate(releaseDate);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

	public Song updatRecordDate(String songID, String recordDate) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		s.setReleaseDate(recordDate);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

	public Song updateFilePath(String songID, String filePath) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Song s = emanager.find(Song.class, songID);
		s.setFilePath(filePath);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

	public Song addArtist(String songID, String artistID) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("SpotifyKnockoffJPA");

		EntityManager emanager = emfactory.createEntityManager();

		emanager.getTransaction().begin();

		Artist a = emanager.find(Artist.class, artistID);

		Song s = emanager.find(Song.class, songID);

		s.setSongArtists(a);
		emanager.persist(s);
		emanager.getTransaction().commit();

		emanager.close();
		emfactory.close();

		return s;

	}

}
